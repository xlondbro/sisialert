
<?php
require_once '../layout/_top.php';
require_once '../helper/connection.php';

$result = mysqli_query($connection, "SELECT * FROM alert");

?>
<style>
.image-container {
  display: flex;
  flex-wrap: wrap; /* Gambar akan pindah ke baris baru jika jumlah maksimum kolom terpenuhi */
  gap: 10px; /* Jarak antar gambar */
}
.image-container img {
  flex: 1 1 calc(33.33% - 10px); /* Setiap gambar mengambil 1/3 lebar kontainer */
  max-width: calc(33.33% - 10px); /* Maksimum 3 kolom */
  height: auto; /* Menjaga proporsi gambar */
}
</style>
<style>
body {font-family: Arial, Helvetica, sans-serif;}

/* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  padding-top: 100px; /* Location of the box */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content */
.modal-content {
  background-color: #fefefe;
  margin: auto;
  padding: 20px;
  border: 1px solid #888;
  width: 60%;
}

/* The Close Button */
.close {
  color: #aaaaaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: #000;
  text-decoration: none;
  cursor: pointer;

}


</style>
<section class="section">
  <div class="section-header d-flex justify-content-between">
    <h1>Alert</h1>

    <a href="./create.php" class="btn btn-primary">Tambah Data</a>
  </div>
  <div class="row">
    <div class="col-12">
      <div class="card">
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-hover table-striped w-100" id="table-1">
              <thead>
                <tr>
                  <th>No</th>
                  <th>ID Problem</th>
                  <th>Host</th>
                  <th>Start Alert</th>
                  <th>Customer </th>
                  <th>Site</th>
                  <th>Kategori Alert</th>
                  <th>Problem</th>
                  <th>Status</th>
                  <th>True False</th>
                  <th>Gambar</th>
                  <th style="width: 150">Aksi</th>
                </tr>
              </thead>
              <tbody>

                <?php  

                $no = 1;
                ?>
                <?php
                while ($data = mysqli_fetch_array($result)) :
                  ?>


                  <tr>
                    <td><?= $no ?></td>
                    <td><?= $data['id_problem'] ?></td>
                    <td><?= $data['host'] ?></td>
                    <td><?=date('d.m.Y', strtotime( $data['alert_date']))?> ON <?=date('H:i:s', strtotime( $data['alert_date']))?></td>
                    <td><?= $data['customer'] ?></td>
                    <td><?= $data['site'] ?></td>
                    <td><?= $data['kategori_alert'] ?></td>
                    <td><?= $data['problem_alert'] ?></td>
                    <td><?= $data['status'] ?></td>
                    <td><?= $data['tf'] ?></td>
                    <td class="gallery">
                       <button id="button<?= $data['id_alert']?>" onclick="openModal(this.id)">Caliak Gambar</button>
                    <!--  <button id="myBtn" onclick="openModal('<?= $data['id_alert']?>')">Caliak Gambar</button>  -->
                       <!-- <?php
                      $images = explode(',', $data['img']);
                        foreach ($images as $image) {
                            echo "<img src='../uploads/$image' alt='Image' id='myImg'  style='width: 100px; height: auto; margin: 5px;' onclick='openModal(this.src)' ><br>";
                        } 
                      ?>  -->

                      <!--  <a href="">Gambar Klik disiko cukk</a> -->

                    </td>
                    <td>
                      <a class="btn btn-sm btn-danger mb-md-0 mb-1" href="delete.php?id_alert=<?= $data['id_alert'] ?>">
                        <i class="fas fa-trash fa-fw"></i>
                      </a>
                      <a class="btn btn-sm btn-info" href="edit.php?id_alert=<?= $data['id_alert'] ?>">
                        <i class="fas fa-edit fa-fw"></i>
                      </a>

                      <!-- The Modal -->
                      <div id="modal-button<?= $data['id_alert']?>" class="modal">

                        <!-- Modal content -->
                        <div class="modal-content">
                          <span class="close">&times;</span>
                          <div class="image-container">
                           <?php
                           $images = explode(',', $data['img']);
                           foreach ($images as $image) {
                            echo "<img src='../uploads/$image' style='width: 300px; height: auto; margin: 5px;' 
                            ><br>";
                          } 
                          ?> 
                        </div>
                      </div>

                    </div>
                 <!--     <div id="modal-button<?= $data['id_alert']?>" class="modal">
                    <div class="modal-content">
                       <div class="image-container">
                        
                        <p> <?php
                           $images = explode(',', $data['img']);
                           foreach ($images as $image) {
                            echo "<img src='../uploads/$image' style='width: 300px; height: auto; margin: 5px;' 
                            ><br>";
                          } 
                          ?> </p>
                       </div>
                    </div>
                </div> -->
 <!-- <div id="imageModal" class="modal">
        <span class="close" onclick="closeModal(this.src)">&times;</span>
        <img class="modal-content" id="modalImage">
      </div> -->
      <!-- The Modal -->

      <div id="<?= $data['id_alert']?>" style="display: none;" class="hidden-text">
        <pre>#### NON CRITICAL ALERT | PROBLEM #######
          ----------------------------------------
          * Host: <?= $data['host'] ?><br>
          * Severity: <?= $data['serverity'] ?><br>
          * Problem: <?= $data['problem_alert'] ?> : Link down<br>
          * Operational data: <br>
          <?= $data['problem_alert'] ?> <br>
          * Problem started at: <?= $data['alert_date'] ?><br>
          * Original problem ID: <?= $data['id_problem'] ?><br>

          --- Dari Monitoring SII ---
          Perangkat Switch Unifi US-24-500W mengalami Link down pada <?= $data['alert_date'] ?>.<br>
          Terlampir graph Operational Status last 2 days.
          Perihal ini minta tolong dibantu pengecekannya tim terkait.
        </pre>
      </div>
      <button class="copyButton" onclick="copyText('<?= $data['id_alert']?>')">Copy Alert</button>
    </div>

  </td>
</tr>

<?php
$no++;
endwhile;
?>
</tbody>

</table>
</div>
</div>
</div>
</div>
</section>

<?php
require_once '../layout/_bottom.php';
?>
<!-- Page Specific JS File -->
<?php
if (isset($_SESSION['info'])) :
  if ($_SESSION['info']['status'] == 'success') {
    ?>
    <script>
      iziToast.success({
        title: 'Sukses',
        message: `<?= $_SESSION['info']['message'] ?>`,
        position: 'topCenter',
        timeout: 5000
      });
    </script>
    <?php
  } else {
    ?>
    <script>
      iziToast.error({
        title: 'Gagal',
        message: `<?= $_SESSION['info']['message'] ?>`,
        timeout: 5000,
        position: 'topCenter'
      });
    </script>
    <?php
  }

  unset($_SESSION['info']);
  $_SESSION['info'] = null;
endif;
?>
<script src="../assets/js/page/modules-datatables.js"></script>
<script>
  function copyText(id) {
            // Get the text content of the element by ID
            const textToCopy = document.getElementById(id).innerText;

            // Copy to clipboard
            navigator.clipboard.writeText(textToCopy)
            .then(() => {
              alert(`Text from ${id} copied to clipboard!`);
            })
            .catch(err => {
              console.error('Failed to copy text: ', err);
              alert('Failed to copy text.');
            });
          }
        </script>

        <script>
  // Open modal and display clicked image

  // function openModal(imageSrc) {
  //   const modal = document.getElementById("imageModal");
  //   const modalImage = document.getElementById("modalImage");
  //   modal.style.display = "block";
  //   modalImage.src = imageSrc;
  // }
     function openModal(buttonId) {
            const modalId = "modal-" + buttonId; // Buat ID modal sesuai ID tombol
            const modal = document.getElementById(modalId);
            if (modal) {
                modal.style.display = "flex"; // Tampilkan modal
            }
        }
        function closeModal(modalId) {
            const modal = document.getElementById(modalId);
            if (modal) {
                modal.style.display = "none"; // Sembunyikan modal
            }
        }
            // Tambahan: Menutup modal saat klik di luar area modal
        window.addEventListener("click", function (e) {
            const modals = document.querySelectorAll(".modal");
            modals.forEach(modal => {
                if (e.target === modal) {
                    modal.style.display = "none";
                }
            });
        });
// Close modal
function closeModal(imageSrc) {
  const modal = document.getElementById("imageModal");
  modal.style.display = "none";
}
window.onclick = function(event) {
  const modal = document.getElementById('imageModal');
  if (event.target === modal) {
    modal.style.display = "none";
  }
}
</script>

<script>
// Get the modal
var modal = document.getElementById("myModal");

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal 
btn.onclick = function() {
  modal.style.display = "block";

}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
</script>